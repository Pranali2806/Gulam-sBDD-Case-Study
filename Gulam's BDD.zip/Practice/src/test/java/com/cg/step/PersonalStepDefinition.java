package com.cg.step;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;
import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal personal;
	private Education education;
	String url = "C:\\Users\\gulshaik\\BDDwork\\Practice\\html\\PersonalDetails.html";

	@Before
	public void init() {
		System.setProperty("webdriver.chrome.driver", "mydriver\\chromedriver.exe");
		driver = new ChromeDriver();

	}

	@After
	public void destroy() {
		driver.quit();
	}

	@Given("^user is on Personal details$")
	public void user_is_on_Personal_details() throws Throwable {
		driver.get(url);
		personal = new Personal();
		PageFactory.initElements(driver, personal);
	}

	@Then("^validate Personal details page$")
	public void validate_Personal_details_page() throws Throwable {
		String title = "Personal Details";
		assertEquals(driver.getTitle(), title);
		Thread.sleep(2000);
		System.out.println("======Title Matched======");
	}

	@When("^user enters First Name$")
	public void user_enters_First_Name() throws Throwable {
		personal.setFirstName("");

	}

	@Then("^validate user First name$")
	public void validate_user_First_name() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters Last Name$")
	public void user_enters_Last_Name() throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("");

	}

	@Then("^validate user Last name$")
	public void validate_user_Last_name() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters Email$")
	public void user_enters_Email() throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("Shaikh");
		personal.setEmail("");

	}

	@Then("^validate user Email$")
	public void validate_user_Email() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);

	}

	@When("^user enters Contact$")
	public void user_enters_Contact() throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("Shaikh");
		personal.setEmail("shaikh@gulam.com");
		personal.setContact("");
	}

	@Then("^validate user Contact$")
	public void validate_user_Contact() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters AddressOne$")
	public void user_enters_AddressOne()throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("Shaikh");
		personal.setEmail("shaikh@gulam.com");
		personal.setContact("7709786028");
		personal.setAddLine1("");
	}

	@Then("^validate user AddressOne$")
	public void validate_user_AddressOne() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	
	@When("^user enters AddressTwo$")
	public void user_enters_AddressTwo() throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("Shaikh");
		personal.setEmail("shaikh@gulam.com");
		personal.setContact("7709786028");
		personal.setAddLine1("Mumbai");
		personal.setAddLine2("");
	}

	@Then("^validate user AddressTwo$")
	public void validate_user_AddressTwo() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters City$")
	public void user_enters_City() throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("Shaikh");
		personal.setEmail("shaikh@gulam.com");
		personal.setContact("7709786028");
		personal.setAddLine1("Mumbai");
		personal.setAddLine2("Bhandup");
		personal.selectCity(0);
	}

	@Then("^validate user City$")
	public void validate_user_City() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^user enters State$")
	public void user_enters_State() throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("Shaikh");
		personal.setEmail("shaikh@gulam.com");
		personal.setContact("7709786028");
		personal.setAddLine1("Bhiwandi");
		personal.setAddLine2("Bhandup");
		personal.selectCity(1);
		personal.selectState(0);
	}

	@Then("^validate user State$")
	public void validate_user_State() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}

	@When("^User submit form$")
	public void user_submit_form() throws Throwable {
		personal.setFirstName("Gulam");
		personal.setLastName("Shaikh");
		personal.setEmail("shaikh@gulam.com");
		personal.setContact("7709786028");
		personal.setAddLine1("Bhiwandi");
		personal.setAddLine2("Bhandup");
		personal.selectCity(1);
		personal.selectState(2);
	}

	@Then("^show successful alert$")
	public void show_successful_alert() throws Throwable {
		personal.clickNext();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	}
	
	@Given("^user is on Educational details$")
	public void user_is_on_Educational_details() throws Throwable {
		String url = "C:\\Users\\gulshaik\\BDDwork\\Practice\\html\\EducationalDetails.html";
		driver.get(url);
		education = new Education();
		PageFactory.initElements(driver, education);
	}

	@Then("^validate Educational details page$")
	public void validate_Educational_details_page() throws Throwable {
		String title = "Education Details";
		assertEquals(driver.getTitle(), title);
		Thread.sleep(2000);
		System.out.println("======Title Matched======");
	
	}

	@When("^user Selects graduation$")
	public void user_Selects_graduation() throws Throwable {
		education.selectGraduation(0);
	}

	@Then("^validate user graduation$")
	public void validate_user_graduation() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
	
	}

	@When("^user enters Percent$")
	public void user_enters_Percent() throws Throwable {
		education.selectGraduation(1);
		education.setPercent("");
	
	}
	@Then("^validate user Percent$")
	public void validate_user_Percent() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);	}

	@When("^user enters Year$")
	public void user_enters_Year() throws Throwable {
		education.selectGraduation(1);
		education.setPercent("75");	
		education.setYear("");
		
	}

	@Then("^validate user Year$")
	public void validate_user_Year() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);	}

	@When("^user enters Project$")
	public void user_enters_Project() throws Throwable {
		education.selectGraduation(1);
		education.setPercent("75");	
		education.setYear("2016");
		education.setProject("");
		
	
	}

	@Then("^validate user Project$")
	public void validate_user_Project() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);	}

	@When("^user selects Technology$")
	public void user_selects_Technology() throws Throwable {
		education.selectGraduation(1);
		education.setPercent("75");	
		education.setYear("2016");
		education.setProject("ToDoApp");
		education.selectTechnology(0);
		
	}

	@Then("^validate user Technology$")
	public void validate_user_Technology() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);	
		}

	@When("^user enters Other Technology$")
	public void user_enters_Other_Technology() throws Throwable {
		education.selectGraduation(1);
		education.setPercent("75");	
		education.setYear("2016");
		education.setProject("ToDoApp");
		education.selectTechnology(4);
		education.setOtherTechnology("");
		
	}

	@Then("^validate user Other Technology$")
	public void validate_user_Other_Technology() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);	
	}
	
	@When("^User submit forms$")
	public void user_submit_forms() throws Throwable {
		education.selectGraduation(1);
		education.setPercent("75");	
		education.setYear("2016");
		education.setProject("ToDoApp");
		education.selectTechnology(3);
	}

	@Then("^show successfull alert$")
	public void show_successfull_alert() throws Throwable {
		education.clickMakePayment();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);	
	}
	
	



}



