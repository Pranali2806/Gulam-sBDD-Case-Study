package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {
	
	@FindBy(id="grad")
	private WebElement graduation;
	
	@FindBy(id="percent")
	private WebElement percent;
	
	@FindBy(id="year")
	private WebElement year;
	
	@FindBy(id="project")
	private WebElement project;
	
	@FindBy(id="otech")
	private WebElement otherTechnology;
	
	@FindBy(id="tech")
	private WebElement technology;

	@FindBy(id="payment")
	private WebElement Payment;
	
	public WebElement getGraduation() {
		return graduation;
	}

//	public void setGraduation(String graduation) {
//		this.graduation.sendKeys(graduation);
//	}
//
//	public WebElement getTechnology() {
//		return technology;
//	}

//	public void setTechnology(String technology) {
//		this.technology.sendKeys(technology);
//	}
//
//	public String getPercent() {
//		return percent.getAttribute("value");
//	}

	public void setPercent(String percent) {
		this.percent.sendKeys(percent);
	}

	public String getYear() {
		return year.getAttribute("value");
	}

	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	public String getProject() {
		return project.getAttribute("value");
	}

	public void setProject(String project) {
		this.project.sendKeys(project);
	}

	public String getOtherTechnology() {
		return otherTechnology.getAttribute("value");
	}

	public void setOtherTechnology(String otherTechnology) {
		this.otherTechnology.sendKeys(otherTechnology);
	}
	
	public void selectGraduation(int idx) {
		Select select = new Select(graduation);
		select.selectByIndex(idx);
	}
	
	public void selectTechnology(int idx) {
		Select select = new Select(technology);
		select.selectByIndex(idx);
	}
	
	public void clickMakePayment() {
		Payment.click();
	}

}
