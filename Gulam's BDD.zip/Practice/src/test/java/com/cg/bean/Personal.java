package com.cg.bean;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {
	
	@FindBy(id="fname")
	private WebElement firstName;
	
	@FindBy(id="lname")
	private WebElement lastName;
	
	@FindBy(id="email")
	private WebElement email;
	
	@FindBy(id="contact")
	private WebElement contact;
	
	@FindBy(id="add1")
	private WebElement addLine1;
	
	@FindBy(id="add2")
	private WebElement addLine2;
	
	@FindBy(id="city")
	private WebElement city;
	
	@FindBy(id="state")
	private WebElement state;
	
	@FindBy(id="next")
	private WebElement next;

	public String getFirstName() {
		return firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getContact() {
		return contact.getAttribute("value");
	}

	public void setContact(String contact) {
		this.contact.sendKeys(contact);;
	}

	public String getAddLine1() {
		return addLine1.getAttribute("value");
	}

	public void setAddLine1(String addLine1) {
		this.addLine1.sendKeys(addLine1);
	}

	public String getAddLine2() {
		return addLine2.getAttribute("value");
	}

	public void setAddLine2(String addLine2) {
		this.addLine2.sendKeys(addLine2);
	}
	
	public void selectCity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}
	
	public void selectState(int idx) {
		Select select = new Select(state);
		select.selectByIndex(idx);
	}
	
//	public WebElement getCity() {
//		return city;
//	}
//
//	public void setCity(String city) {
//		this.city.sendKeys(city);
//	}
//
//	public WebElement getState() {
//		return state;
//	}
//
//	public void setState(String state) {
//		this.state.sendKeys(state);
//	}

	public void clickNext() {
		next.click();
	}
	
	
	

}
